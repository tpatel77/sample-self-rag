"""Configuration module for workflow schemas."""
