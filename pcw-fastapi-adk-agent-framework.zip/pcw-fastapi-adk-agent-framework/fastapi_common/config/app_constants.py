# Application Constants
CONFIG_APP_NAME = "info.app.name"
CONFIG_APP_DESCRIPTION = "info.app.description"
CONFIG_APP_VERSION = "info.app.version"
CONFIG_OPERATION_NAMES = "info.app.operationNames"
CONFIG_RESOURCE_NAME = "info.app.resourceName"
CONFIG_CONTEXT_PATH = "info.app.context-path"
